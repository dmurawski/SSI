import numpy as np
import matplotlib.pyplot as plt
import random


def funkcja_przystostowania(x):
    if x >= 0 and x<=100:
        return np.sin(x/10)*np.sin(x/200)
    else:
        print("x musi być z przedziału [0; 100]")

def alogytrm_1_1(rozrzut, wsp_przyrostu, l_iteracji, zakres_zmiennosci):
    x = random.uniform(0, zakres_zmiennosci)
    y = funkcja_przystostowania(x)
    for i in range(l_iteracji):
        xp = x + random.uniform(-rozrzut, rozrzut)
        xp=np.abs(xp)
        if xp > zakres_zmiennosci:
            roznica_xp = np.abs(xp-zakres_zmiennosci)
            xp = xp - roznica_xp
            yp = funkcja_przystostowania(xp)
        else:
            yp = funkcja_przystostowania(xp)
        if yp >= y:
            x = xp
            y = yp
            rozrzut *= wsp_przyrostu
        if(yp<y):
            rozrzut /=wsp_przyrostu
        y_wykres = []
        y_wykres.append([])
        x_wykres = []
        x_wykres.append([])
        y_wykres.append(y)
        x_wykres.append(x)
        plt.scatter(x_wykres[i],y_wykres[i],marker='x',color='red',label='')
        plt.show()
            
alogytrm_1_1(10,1.1,100,5)
